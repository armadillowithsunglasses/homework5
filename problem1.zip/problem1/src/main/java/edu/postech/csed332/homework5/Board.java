package edu.postech.csed332.homework5;

import org.jetbrains.annotations.NotNull;

/**
 * An even-odd Sudoku board
 */
public class Board {
    //TODO: add private member variables for Board

    private Cell[][] cells;
    private GameInstance game;
    private Group[] rowgroups;
    private Group[] colgroups;
    private Group[][] sqgroups;


    /**
     * Creates an even-odd Sudoku board
     *
     * @param game an initial configuration
     */
    Board(@NotNull GameInstance game) {
        //TODO: implement this
        cells = new Cell[9][9];
        rowgroups = new Group[9];
        colgroups = new Group[9];
        sqgroups = new Group[3][3];

        this.game= game;

        for(int i=0;i<9;i++)
        {rowgroups[i] = new Group();
          colgroups[i]= new Group();
        }

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
              sqgroups[i][j] = new Group();
            }

        }

        for(int a=0;a<9;a++)
        {
            for(int b=0;b<9;b++)
            {
                if(game.isEven(a,b))
                {cells[a][b] = new Cell( Cell.Type.EVEN);}
                else
                { cells[a][b] = new Cell(Cell.Type.ODD);
                }

                rowgroups[a].addCell(cells[a][b]);
                colgroups[b].addCell(cells[a][b]);
                sqgroups[a/3][b/3].addCell(cells[a][b]);
            }

        }




        for(int a=0;a<=8;a++)
        {
            for(int b=0;b<=8;b++)
            {

                //System.out.println("steps for cell"+(a)+b+":"+game.getNumbers(a,b));
                if(!game.getNumbers(a,b).isEmpty())
                {
                    //System.out.println("creating the board numbers"+game.getNumbers(a,b));
                    cells[a][b].setNumber(Integer.valueOf(game.getNumbers(a,b).get()));

                }



            }



        }





    }

    /**
     * Returns a cell in the (i+1)-th row of (j+1)-th column, where 0 <= i, j < 9.
     *
     * @param i a row index
     * @param j a column index
     * @return a cell in the (i+1)-th row of (j+1)-th column
     */
    @NotNull
    Cell getCell(int i, int j) {
        //TODO: implement this

        return cells[i][j];
    }

    /**
     * Returns a group for the (i+1)-th row, where 0 <= i < 9.
     *
     * @param i a row index
     * @return a group for the (i+1)-th row
     */
    @NotNull
    Group getRowGroup(int i) {
        //TODO: implement this
        return rowgroups[i];
    }

    /**
     * Returns a group for the (j+1)-th column, where 0 <= j < 9.
     *
     * @param j a column index
     * @return a group for the (j+1)-th column
     */
    @NotNull
    Group getColGroup(int j) {
        //TODO: implement this
        return colgroups[j];
    }

    /**
     * Returns a square group for the (n+1)-th row of (m+1)-th column, where 1 <= n, m <= 3
     *
     * @param n a square row index
     * @param m a square column index
     * @return a square group for the (n+1)-th row of (m+1)-th column
     */
    @NotNull
    Group getSquareGroup(int n, int m) {
        //TODO: implement this
        return sqgroups[n][m];
    }
}
