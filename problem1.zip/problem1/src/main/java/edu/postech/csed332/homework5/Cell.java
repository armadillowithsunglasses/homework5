package edu.postech.csed332.homework5;

import edu.postech.csed332.homework5.events.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * A cell that has a number and a set of possibilities. Even cells can contain only even numbers, and odd cells can
 * contain only odd numbers. A cell may have a number of observers, and notifies events to the observers.
 */
public class Cell extends Subject {
    enum Type {EVEN, ODD}
    Type this_type;
    private Optional<Integer> number;
    private Set<Integer> possibility;
    private List<Group> groups;
    //TODO: add private member variables for Board

    /**
     * Creates an empty cell with a given type. Initially, no number is assigned.
     *
     * @param type EVEN or ODD
     */
    public Cell(@NotNull Type type) {
        //TODO: implement this
        this.this_type=type;
        possibility= new HashSet<Integer>();
        groups = new ArrayList<Group>() ;
        switch (this_type){

            case ODD:
                possibility.add(1);possibility.add(3);possibility.add(5);
                possibility.add(7);possibility.add(9);
                break;
            case EVEN:
                possibility.add(2);possibility.add(4);possibility.add(6);
                possibility.add(8);
                break;
        }

        this.number=Optional.empty();

    }

    /**
     * Returns the type of this cell.
     *
     * @return the type
     */
    @NotNull
    public Type getType() {
        //TODO: implement this
        return this_type;
    }

    /**
     * Returns the number of this cell.
     *
     * @return the number; Optional.empty() if no number assigned
     */
    @NotNull
    public Optional<Integer> getNumber() {
        //TODO: implement this
        if(number.isEmpty())
        {
            return Optional.empty();
        }

        return this.number;
    }
    /**
     * Sets a number of this cell and notifies a SetNumberEvent, provided that the cell has previously no number
     * and the given number to be set is in the set of possibilities.
     *
     * @param number the number
     */
    public void setNumber(int number) {
        //TODO: implement this
        //System.out.println("REACHED SET NUMBER" +number);

        if(containsPossibility(number) && (this.number.isEmpty())) {
            //System.out.println("REACHED inside"+super.getObservers());
            this.number = Optional.of(number);
            super.notifyObservers(new SetNumberEvent(Integer.valueOf(this.number.get())));
        }


    }

    /**
     * Removes the number of this cell and notifies an UnsetNumberEvent, provided that the cell has a number.
     */
    public void unsetNumber() {
        //TODO: implement this
        //System.out.println("REACHED UNSETNUMBER");
        int temp =Integer.valueOf(this.number.get());
        if(!this.number.isEmpty())
        {
            this.number=Optional.empty();
            super.notifyObservers(new UnsetNumberEvent(temp));


        }


    }

    /**
     * Adds a group for this cell. This methods should also call addObserver(group).
     *
     * @param group
     */
    public void addGroup(@NotNull Group group) {
        addObserver(group);
        groups.add(group);

        //TODO: implement this
    }

    /**
     * Returns true if a given number is in the set of possibilities
     *
     * @param n a number
     * @return true if n is in the set of possibilities
     */
    @NotNull
    public Boolean containsPossibility(int n) {
        //TODO: implement this
        for(int num:possibility)
        {
            if(num==n)
            {
                return true;
            }

        }

        return false;
    }

    /**
     * Returns true if the cell has no possibility
     *
     * @return true if the set of possibilities is empty
     */
    @NotNull
    public Boolean emptyPossibility() {
        //TODO: implement this

        if(possibility.isEmpty())
        return true;

        return false;
    }

    /**
     * Adds the possibility of a given number, if possible, and notifies an EnabledEvent if the set of possibilities,
     * previously empty, becomes non-empty. Even (resp., odd) cells have only even (resp., odd) possibilities. Also,
     * if this number is already used by another cell in the same group with this cell, the number cannot be added to
     * the set of possibilities.
     *
     * @param number the number
     */
    public void addPossibility(int number) {
        //TODO: implement this
int flag=0;
        for(Group g:groups)
        {
            for(Cell c:g.getGroup())
            {
                if(!c.getNumber().isEmpty()&& Integer.valueOf(c.getNumber().get())==number)
                {
                    flag=1;
                    break;
                }

            }

        }

        switch (this_type){

            case ODD:
                if(number%2==0)
                {
                    flag=1;
                }
                break;
            case EVEN:
                if(number%2!=0)
                {
                    flag=1;
                }

                break;
        }


        if(flag==0 && this.emptyPossibility())
        {   super.notifyObservers(new EnabledEvent());
            possibility.add(number);
        }
        else if(flag==0)
        {
            possibility.add(number);
        }



    }

    /*
     * Removes the possibility of a given number. Notifies a DisabledEvent if the set of possibilities becomes empty.
     * Note that even (resp., odd) cells have only even (resp., odd) possibilities.
     *
     * @param number the number
     */
    public void removePossibility(int number) {
        //TODO: implement this
        if(containsPossibility(number))
        {
            possibility.remove(number);

        }

        if( possibility.isEmpty())
        {
            //System.out.println("disabling event "+ this.number);
            super.notifyObservers(new DisabledEvent());
        }






    }
}
