package edu.postech.csed332.homework5;

import edu.postech.csed332.homework5.events.DisabledEvent;
import edu.postech.csed332.homework5.events.EnabledEvent;
import edu.postech.csed332.homework5.events.Event;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class CellUI extends JTextField implements Observer {

    /**
     * create a cell UI
     *
     * @param cell a cell model
     */
    CellUI(Cell cell) {
        cell.addObserver(this);
        initCellUI(cell);

        if (cell.getNumber().isEmpty()) {
            //TODO: whenever the content is changed, cell.setNumber() or cell.unsetNumber() is accordingly invoked.
            // You may use an action listener, a key listener, a document listener, etc.

            this.addKeyListener(new KeyAdapter() {
                public void keyPressed(KeyEvent evt) {

                    System.out.println(evt.getKeyChar()+" key pressed");
                    if(evt.getKeyCode()== KeyEvent.VK_BACK_SPACE || evt.getKeyCode()== KeyEvent.VK_DELETE)
                    {  //System.out.println(evt.getKeyChar()+" here");
                        cell.unsetNumber();
                    }
                    else if(evt.getKeyCode()>=KeyEvent.VK_1 && evt.getKeyChar()<=KeyEvent.VK_9 )
                    {
             //(cell.getType()== Cell.Type.EVEN )&&((int)(evt.getKeyChar()-'0')%2==0)

                        if(cell.containsPossibility((int)(evt.getKeyChar()-'0')))
                        {
                            cell.setNumber((int)(evt.getKeyChar()-'0'));
                            if(cell.emptyPossibility())
                            {setText(cell.getNumber().get().toString());}

                        }else
                        {
                            JOptionPane.showMessageDialog(null, "Sorry, against game rules");
                        }
                        /*else if((cell.getType()== Cell.Type.ODD )&&((int)(evt.getKeyChar()-'0')%2!=0) )
                        {cell.setNumber((int)(evt.getKeyChar()-'0'));
                            if(cell.emptyPossibility())
                            {setText(cell.getNumber().get().toString());}
                        }*/
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Invalid input");
                    }


                }
            });

        }
    }

    /**
     * Mark this cell UI as active
     */
    public void setActivate() {
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setEditable(true);
    }

    /**
     * Mark this cell UI as inactive
     */
    public void setDeactivate() {
        setBorder(BorderFactory.createLineBorder(Color.RED));

        setEditable(false);
    }

    /**
     * Whenever a cell is changed, this function is called. EnabledEvent and DisabledEvent are handled here.
     * If the underlying cell is enabled, mark this cell UI as active. If the underlying cell is disabled, mark
     * this cell UI as inactive.
     *
     * @param caller the subject
     * @param arg    an argument passed to caller
     */
    @Override
    public void update(Subject caller, Event arg) {
        //TODO: implement this
//System.out.println("inside update cellUI"+arg.getClass());
        if(arg instanceof EnabledEvent)
        {
            //System.out.println("inside setactivate");
            setActivate();
        }
        else if(arg instanceof DisabledEvent)
        {
            //System.out.println("inside setdeactivate");

            setDeactivate();
        }

    }

    /**
     * Initialize this cell UI
     *
     * @param cell a cell model
     */
    private void initCellUI(Cell cell) {
        setFont(new Font("Times", Font.BOLD, 30));
        setHorizontalAlignment(JTextField.CENTER);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));

        if (cell.getType() == Cell.Type.EVEN)
            setBackground(Color.LIGHT_GRAY);

        if (cell.getNumber().isPresent()) {
            setForeground(Color.BLUE);
            setText(cell.getNumber().get().toString());
            setEditable(false);
        }
    }
}
