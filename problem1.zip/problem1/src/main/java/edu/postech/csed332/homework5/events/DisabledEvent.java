package edu.postech.csed332.homework5.events;

/**
 * An event indicating that a cell has lost all possibilities.
 */
public class DisabledEvent implements Event {
}
