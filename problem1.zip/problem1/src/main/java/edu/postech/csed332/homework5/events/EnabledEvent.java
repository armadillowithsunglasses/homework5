package edu.postech.csed332.homework5.events;

/**
 * An event indicating that a cell, previously disabled, has obtained some possibility
 */
public class EnabledEvent implements Event {
}
