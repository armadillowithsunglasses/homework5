package edu.postech.csed332.homework5.events;

/**
 * A base interface for arguments of Observer's update
 */
public interface Event {
}
